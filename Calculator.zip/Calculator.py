import tkinter as tk
from tkinter import messagebox


def button_click(char):
    current = entry_display.get()
    if char == "C":
        entry_display.delete(0, tk.END)
    else:
        entry_display.delete(0, tk.END)
        entry_display.insert(0, current + char)


def calculate():
    try:
        expression = entry_display.get()
        # Replace symbols for evaluation
        expression = expression.replace("×", "*").replace("÷", "/")
        result = eval(expression)
        entry_display.delete(0, tk.END)
        entry_display.insert(0, str(result))
        label_history.config(text="History: {}".format(expression))
    except ZeroDivisionError:
        messagebox.showerror("Error", "Cannot divide by zero!")
        entry_display.delete(0, tk.END)
    except Exception as e:
        messagebox.showerror("Error", "Invalid input!")
        entry_display.delete(0, tk.END)


# Create main window
window = tk.Tk()
window.title("Simple Calculator")
window.geometry("300x400")
window.configure(bg="#e0e0e0")  # Light gray background
window.resizable(False, False)

# Main frame for alignment
frame = tk.Frame(window, bg="#e0e0e0", padx=15, pady=15)
frame.pack(expand=True, fill="both")

# Title label
label_title = tk.Label(
    frame, text="Calculator", font=("Arial", 16, "bold"),
    bg="#e0e0e0", fg="#212121"
)
label_title.grid(row=0, column=0, columnspan=4, pady=(0, 10))

# History label (to show the last calculation)
label_history = tk.Label(
    frame, text="History: ", font=("Arial", 10),
    bg="#e0e0e0", fg="#616161"
)
label_history.grid(row=1, column=0, columnspan=4, sticky="w", pady=(0, 5))

# Display entry
entry_display = tk.Entry(
    frame, width=20, font=("Arial", 14),
    bg="#ffffff", fg="#212121", bd=5, relief="sunken"
)
entry_display.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(0, 15))

# Button layout
buttons = [
    ("7", 3, 0), ("8", 3, 1), ("9", 3, 2), ("÷", 3, 3),
    ("4", 4, 0), ("5", 4, 1), ("6", 4, 2), ("×", 4, 3),
    ("1", 5, 0), ("2", 5, 1), ("3", 5, 2), ("-", 5, 3),
    ("0", 6, 0), ("C", 6, 1), ("=", 6, 2), ("+", 6, 3)
]

# Create buttons
for (text, row, col) in buttons:
    if text in {"+", "-", "×", "÷", "="}:
        bg_color = "#ff9800"  # Orange for operation buttons
        active_bg = "#f57c00"
    elif text == "C":
        bg_color = "#f44336"  # Red for clear button
        active_bg = "#d32f2f"
    else:
        bg_color = "#bdbdbd"  # Gray for number buttons
        active_bg = "#9e9e9e"

    button = tk.Button(
        frame, text=text, font=("Arial", 12, "bold"),
        bg=bg_color, fg="#ffffff", activebackground=active_bg,
        width=5, height=2, command=lambda x=text: button_click(x) if x != "=" else calculate()
    )
    button.grid(row=row, column=col, padx=5, pady=5)

# Configure grid weights for responsive layout
frame.columnconfigure((0, 1, 2, 3), weight=1)
frame.rowconfigure((3, 4, 5, 6), weight=1)

# Start the main loop
window.mainloop()